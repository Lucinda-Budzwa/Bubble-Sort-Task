package com.myproject.bubblesorttask;

public class BubbleSortTask {

    // This method sorts an array of numbers from smallest to largest
    public static void bubbleSort(int[] arr) {
        int n = arr.length; // Find the total number of items in the array

        // Loop to go through the array multiple times
        for (int i = 0; i < n - 1; i++) {
            
            // Loop to compare two numbers that are next to each other
            for (int j = 0; j < n - i - 1; j++) {
                
                // If the left number is bigger than the right number, swap them
                if (arr[j] > arr[j + 1]) {
                    // 1. Save the first number in a temporary variable
                    int temp = arr[j];
                    
                    // 2. Put the second number into the first position
                    arr[j] = arr[j + 1];
                    
                    // 3. Put the temporary number into the second position
                    arr[j + 1] = temp;
                }
            }
        }
    }

    // This method prints all the numbers in the array on the screen
    public static void printArray(int[] arr) {
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " "); // Print each number followed by a space
        }
        System.out.println(); // Move to the next line
    }

    // The main method where the program starts running
    public static void main(String[] args) {
        // Create an example array with numbers
        int[] data = {5, 2, 9, 1, 6};

        // Print the original array
        System.out.println("Array before sorting:");
        printArray(data);

        // Call the method to sort the array
        bubbleSort(data);

        // Print the array after it has been sorted
        System.out.println("Array after sorting:");
        printArray(data);
    }
}
